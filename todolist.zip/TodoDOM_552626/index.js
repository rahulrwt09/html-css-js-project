document.querySelector("form").addEventListener("submit", todo)
function todo(event){
    event.preventDefault()
    let task_name= document.querySelector("#task").value
    let task_priority=document.querySelector("#priority").value
    console.log(task_priority);
   
    
    let trow= document.createElement("tr");
    
    let td1= document.createElement("td")
    td1.innerHTML=task_name; 
     console.log(td1)
    let td2 =document.createElement("td")
    td2.innerHTML=task_priority
     if(task_priority=="High" ){
        td2.style.backgroundColor="green"
     }
     else {
         td2.style.backgroundColor="yellow"
     }
     
    

    let td3= document.createElement("td")
    td3.innerText="delete list"
    td3.addEventListener("click", deletelist)
    td3.style.backgroundColor="red"
    
    trow.append(td1,td2,td3);
    document.querySelector("tbody").append(trow)

     function deletelist(event){
       event.target.parentNode.remove();

     }
     
}