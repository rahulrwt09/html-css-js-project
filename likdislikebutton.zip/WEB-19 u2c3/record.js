 // fill in javascript code here
 document.querySelector("form").addEventListener("submit", addrecord);
 function addrecord(event){
    event.preventDefault()
   let empname= document.querySelector("#name").value;

   let empid=document.querySelector("#employeeID").value;

   let department=document.querySelector("#department").value;

   let Experience=document.querySelector("#exp").value;

   let text=document.querySelector("#email").value;

   let mbl=document.querySelector("#mbl").value;
  
  
  
  
   let trow=document.createElement("tr");

   let td1=document.createElement("td")
     td1.innerText=empname;

   let td2=document.createElement("td")
      td2.innerText=empid;

   let td3=document.createElement("td")
       td3.innerText=department;

   let td4=document.createElement("td")
      td4.innerText=Experience;

   let td5=document.createElement("td")
       td5.innerText=text;

   let td6=document.createElement("td")
       td6.innerText=mbl;

    let td7=document.createElement("td");
       td7.innerText="Delete"
       td7.style.backgroundColor="red"
        td7.addEventListener("click" , deletelist)

        
    trow.append(td1,td2,td3,td4,td5,td6,td7)
   document.querySelector("tbody").append(trow)
    function deletelist(event){
        event.target.parentNode.remove()
    }
}